import Head from 'next/head';
import Link from 'next/link';
import { useSession, signIn, signOut } from 'next-auth/react';
import Image from 'next/image';
import { useState } from 'react'; // svarbus importas hamburger meniu

// i18n importai
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { useRouter } from 'next/router';

export default function Home() {
  const { t } = useTranslation('common');
  const { data: session, status } = useSession();
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  // Kalbos keitimas
  const changeLanguage = (lng) => {
    router.push(router.pathname, router.asPath, { locale: lng });
  };

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>{t('loading')}</p>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>BraveStep</title>
      </Head>
      {/* NAVBAR */}
      <nav className="w-full bg-white shadow-sm py-4">
        <div className="container mx-auto flex justify-between items-center px-6">
          {/* Kairė: logotipas + meniu */}
          <div className="flex items-center">
            {/* Meniu matomas tik kompiuteryje */}
            <ul className="hidden md:flex gap-8">
              <li><Link href="/"><span className="hover:text-blue-700">{t('menu.home')}</span></Link></li>
              <li><Link href="#"><span className="hover:text-blue-700">{t('menu.workouts')}</span></Link></li>
              <li><Link href="#"><span className="hover:text-blue-700">{t('menu.nutrition')}</span></Link></li>
              <li><Link href="#"><span className="hover:text-blue-700">{t('menu.health')}</span></Link></li>
            </ul>
          </div>
          {/* Dešinė: SignIn, kalbos pasirinkimas ir hamburger */}
          <div className="flex items-center gap-4">
            {/* Kalbos pasirinkimas */}
            <div className="flex gap-2 mr-2">
              <button onClick={() => changeLanguage('en')} className={`px-2 ${router.locale === 'en' ? 'font-bold underline' : ''}`}>EN</button>
              <button onClick={() => changeLanguage('lt')} className={`px-2 ${router.locale === 'lt' ? 'font-bold underline' : ''}`}>LT</button>
            </div>
            {/* SignIn/SignOut matomas tik kompiuteryje */}
            <div className="hidden md:block">
              {session ? (
                <button onClick={() => signOut()} className="hover:text-blue-700">{t('signOut')}</button>
              ) : (
                <button onClick={() => signIn()} className="hover:text-blue-700">{t('signIn')}</button>
              )}
            </div>
            {/* Hamburger meniu tik telefone */}
            <button
              className="md:hidden focus:outline-none"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
            >
              <span className="text-3xl">☰</span>
            </button>
          </div>
        </div>
        {/* Mobile overlay meniu */}
        {menuOpen && (
          <div className="fixed inset-0 bg-white bg-opacity-95 flex flex-col items-center justify-center z-50 transition-all">
            <button
              className="absolute top-6 right-6 text-3xl"
              onClick={() => setMenuOpen(false)}
              aria-label="Close menu"
            >×</button>
            <ul className="flex flex-col gap-10 text-2xl font-semibold">
              <li onClick={() => setMenuOpen(false)}><Link href="/">{t('menu.home')}</Link></li>
              <li onClick={() => setMenuOpen(false)}><Link href="#">{t('menu.workouts')}</Link></li>
              <li onClick={() => setMenuOpen(false)}><Link href="#">{t('menu.nutrition')}</Link></li>
              <li onClick={() => setMenuOpen(false)}><Link href="#">{t('menu.health')}</Link></li>
              <li>
                {session ? (
                  <button
                    onClick={() => { setMenuOpen(false); signOut(); }}
                    className="hover:text-blue-700"
                  >{t('signOut')}</button>
                ) : (
                  <button
                    onClick={() => { setMenuOpen(false); signIn(); }}
                    className="hover:text-blue-700"
                  >{t('signIn')}</button>
                )}
              </li>
              {/* Kalbos pasirinkimas mobiliajame */}
              <li className="flex gap-2 justify-center">
                <button onClick={() => { changeLanguage('en'); setMenuOpen(false); }} className={`px-2 ${router.locale === 'en' ? 'font-bold underline' : ''}`}>EN</button>
                <button onClick={() => { changeLanguage('lt'); setMenuOpen(false); }} className={`px-2 ${router.locale === 'lt' ? 'font-bold underline' : ''}`}>LT</button>
              </li>
            </ul>
          </div>
        )}
      </nav>

      {/* HEADER */}
      <header className="container mx-auto flex flex-col md:flex-row items-center justify-between py-12 px-6">
        {/* Left side: Text */}
        <div className="flex-1 mb-10 md:mb-0 flex flex-col items-start md:items-center md:text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            {t('welcomeTitle')}
          </h1>
          <p className="text-gray-600 mb-7">
            {t('welcomeSubtitle')}
          </p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white py-3 px-7 rounded-lg font-semibold text-lg shadow-md">
            {t('getStarted')}
          </button>
        </div>
        {/* Right side: Illustration */}
        <div className="flex-1 flex justify-center ml-20">
          <Image
            src="/hero.png"
            alt="Walking person"
            width={300}
            height={300}
            priority
            style={{ maxWidth: '100%', height: 'auto' }}
          />
        </div>
      </header>

      {/* FEATURES */}
      <section className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-7 pb-16 px-6">
        {/* Feature 1 */}
        <div className="bg-white rounded-xl shadow-md flex flex-col items-center p-2">
          <div className="text-4xl mb-4">🏋️‍♂️</div>
          <h3 className="font-bold text-lg mb-2">{t('features.workoutsTitle')}</h3>
          <p className="text-gray-600 text-center">{t('features.workoutsText')}</p>
        </div>
        {/* Feature 2 */}
        <div className="bg-white rounded-xl shadow-md flex flex-col items-center p-2">
          <div className="text-4xl mb-4">✅</div>
          <h3 className="font-bold text-lg mb-2">{t('features.mealTitle')}</h3>
          <p className="text-gray-600 text-center">{t('features.mealText')}</p>
        </div>
        {/* Feature 3 */}
        <div className="bg-white rounded-xl shadow-md flex flex-col items-center p-2">
          <div className="text-4xl mb-4">📊</div>
          <h3 className="font-bold text-lg mb-2">{t('features.trackTitle')}</h3>
          <p className="text-gray-600 text-center">{t('features.trackText')}</p>
        </div>
      </section>
    </>
  );
}

// SSR i18n palaikymui
export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
