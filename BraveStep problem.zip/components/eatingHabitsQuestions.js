export const eatingHabitsQuestions = [
  {
    key: "burgerIsHealthy",
    label: "form.eatingHabitsQuestions.burgerIsHealthy",
  },
  {
    key: "buysFreshVeggies",
    label: "form.eatingHabitsQuestions.buysFreshVeggies",
  },
  {
    key: "fastFoodOften",
    label: "form.eatingHabitsQuestions.fastFoodOften",
  },
  {
    key: "eatsBreakfastDaily",
    label: "form.eatingHabitsQuestions.eatsBreakfastDaily",
  },
  {
    key: "avoidsSugar",
    label: "form.eatingHabitsQuestions.avoidsSugar",
  },
  {
    key: "prefersHomeCooking",
    label: "form.eatingHabitsQuestions.prefersHomeCooking",
  },
  {
    key: "eatsProcessedFoods",
    label: "form.eatingHabitsQuestions.eatsProcessedFoods",
  },
];
