import { useTranslation } from 'next-i18next';

export default function MemberSection({ user }) {
  const { t } = useTranslation('common');
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <h1 className="text-3xl font-bold">{t('hello')}, {user?.name || user?.email}!</h1>
      <p className="mt-4 text-lg">{t('memberWelcome', 'You are logged in. More features coming soon!')}</p>
    </div>
  );
}
