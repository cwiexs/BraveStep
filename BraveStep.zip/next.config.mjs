/** @type {import('next').NextConfig} */
export default {};
