import { describe, it, expect } from 'vitest';

describe('sample', () => {
  it('adds numbers', () => {
    expect(1 + 1).toBe(2);
  });
});